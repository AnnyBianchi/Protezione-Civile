<?php
    //variabili utili alla connessione
    $HOSTDB="localhost";
    $USERDB="root";
    $PASSDB="root";
    $NAMEDB="protezione_civile_db"; 


?>